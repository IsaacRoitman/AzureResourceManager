using namespace System.Net

# Input bindings are passed in via param block.
param($Request, $TriggerMetadata)

# Write to the Azure Functions log stream.
Write-Host $("PowerShell HTTP trigger function processed a request at $(Get-Date).")

# Create rows object from data in the request body.
$rows = $Request.body

# Create vault properties from the Vault Resource ID.
$vaultObject = $rows[3] -split '/'

# Create backup item properties from the Backup Item Unique ID.
$backupItemObject = $rows[7] -split ';'

# Create the main PS custom object.
$object = [pscustomobject]@{
    "VaultSubscriptionId" = $vaultObject[2]
    "VaultResourceGroup" = $vaultObject[4]

    "BackupItemLocation" = $backupItemObject[0]
    "BackupItemVaultId" = $backupItemObject[1]
    "BackupItemType" = $backupItemObject[2]
    "BackupItemResourceGroup" = $backupItemObject[3]
    "BackupItemFriendlyName" = $backupItemObject[4]

    "TenantId" = $rows[0]
    "SourceSystem" = $rows[1]
    "TimeGenerated" = [datetime]$rows[2]
    "ResourceId" = $rows[3].ToLower()
    "OperationName" = $rows[4]
    "Category" = $rows[5]
    "AdHocOrScheduledJob" = $rows[6]
    "BackupItemUniqueId" = $rows[7]
    "BackupManagementServerUniqueId" = $rows[8]
    "BackupManagementType" = $rows[9]
    "DataTransferredInMB" = [int]$rows[10]
    "JobDurationInSecs" = [int]$rows[11]
    "JobFailureCode" = $rows[12]
    "JobOperation" = $rows[13]
    "JobOperationSubType" = $rows[14]
    "JobStartDateTime" = [datetime]$rows[15]
    "JobStatus" = $rows[16]
    "JobUniqueId" = $rows[17]
    "ProtectedContainerUniqueId" = $rows[18]
    "RecoveryJobDestination" = $rows[19]
    "RecoveryJobRPDateTime" = if ($null -eq $rows[20]) {$null} else {[datetime]$rows[20]}
    "RecoveryJobRPLocation" = $rows[21]
    "RecoveryLocationType" = $rows[22]
    "SchemaVersion" = $rows[23]
    "State" = $rows[24]
    "VaultUniqueId" = $rows[25]
    "DatasourceSetFriendlyName" = $rows[26]
    "DatasourceSetResourceId" = $rows[27]
    "DatasourceSetType" = $rows[28]
    "DatasourceResourceId" = $rows[29]
    "DatasourceType" = $rows[30]
    "DatasourceFriendlyName" = $rows[31]
    "SubscriptionId" = $rows[32]
    "ResourceGroupName" = $rows[33]
    "VaultName" = $rows[34]
    "VaultTags" = $rows[35]
    "VaultType" = $rows[36]
    "StorageReplicationType" = $rows[37]
    "ArchiveTierStorageReplicationType" = $rows[38]
    "AzureDataCenter" = $rows[39]
    "BackupItemId_" = $rows[40]
    "BackupItemFriendlyName_" = $rows[41]
    "Type" = $rows[42]
    "ResourceId_" = $rows[43]
}

# Select only relevant properties from the object (for failed backup jobs) and create the body to return.
$body = $object | Select-Object VaultSubscriptionId, VaultResourceGroup, BackupItemLocation, BackupItemVaultId, BackupItemType, BackupItemResourceGroup,`
    BackupItemFriendlyName, TenantId, SourceSystem, TimeGenerated, ResourceId, OperationName, Category, AdHocOrScheduledJob, BackupItemUniqueId,`
    BackupManagementType, DataTransferredInMB, JobDurationInSecs, JobFailureCode, JobOperation, JobStartDateTime, JobStatus, JobUniqueId,`
    ProtectedContainerUniqueId, SchemaVersion, State, VaultUniqueId, Type

# Associate values to output bindings by calling 'Push-OutputBinding'.
Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
    StatusCode = [HttpStatusCode]::OK
    Body = $body
})
